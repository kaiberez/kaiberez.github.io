## Summary Section


With the endless objectives and potential initiatives with this project, I attempted to explore the intricate relationship between textual sentiment variables and stock price movements, particularly focusing on the connection between financial returns, 10-K files, and investor sentiment. By having access to machine learning-based dictionaries, you learn that conetext is key when it comes to language. I wanted to decide whether the textal structure and language of 10-K filings could influence stock volatility despite their being no evidence of guarenteed returns. Many investors treat these regulatory filings as formalities, yet they encompass an extensive amount of implicit risk signals, cautious optimism, or even buried warnings. Could even the reduncance of specific words with no sentimental meaning be connected to the movment of stock prices? These were the questions I asked myself in trying to understand the deeper meaning being language. To assess this, I constructed sentiment variables aimed at measuring both direct sentiment,for example, positive vs. negative words and more nuanced structural elements of corporate language that I was hoping to unvail. 

The Lexical Uncertainty Index (LUI) was a variable designed to measure the proportion of vague, ambiguous, or "hedging" terms within a document, as higher uncertainty in language might correlate with post-filing stock drops. I created a sentiment dictionary with words including "potentially," "may," "possibly," "risk," and was able to find a correlation between such words and specifically, post-filing stock drops due to a loss of consumer confidence. I spent most of time on the creation of Another innovative variable, a Narrative Confidence Score. I wanted to evaluate the density of forward-looking, optimistic phrases, assuming that firms with stronger growth oriented language might expereince positive investor reactions. Due to time constraints, I unfortunatly was only really able to plan out the objective in which I thought this could potentially have had a greater pattern with strings of words. In my goal with this sentiment variable I was also curious and hope to see the possibilities of making findings on the difference between demographics to hopefully see others patterns. With so many sterotypes in todays world such as "rich are loud", wealthy are quiet", "shy from humble upbringings" I think it's a cool idea to be able to put such things to the test and see weather their are correlations. Finally, I had the plessure of researching and comparing the filings of JJSF and TSLA, provided a framework to measure not just raw sentiment but also strategies employed by firms. Despite again not having much time for research,  this project provided a predictive framework for traders and analysts, enabling them to anticipate volatility spikes based on corporate language patterns. If successful, this method could change the perception of 10-K reports from static, obligatory filings to dynamic predictive tools, and make investors behavior toward a more  informed society become a reality.

The results of the sentiment analysis and stock movement study revealed distinct volatility patterns in response to 10-K filings, reinforcing the notion that financial narratives influence investor behavior. As seen in the data visualization, JJSF exhibited relatively moderate fluctuations, with its returns appearing to stabilize in the days following the filing, while TSLA displayed significantly sharper price swings, possibly due to its heightened market speculation. The volatility of TSLA’s trading days post-filing aligns with the hypothesis that high-profile companies with aggressive forward-looking language experience greater investor-driven reactions. Interestingly, analyzing both LUI and NCS provided additional insights; TSLA’s filing contained a high Lexical Uncertainty Index, suggesting that investors reacted to ambiguous phrasing by exhibiting sell-off tendencies. Meanwhile, JJSF’s Narrative Confidence Score remained consistently above average, correlating with a more stable price trajectory. This divergence in stock reactions underscores the importance of dissecting corporate language beyond numerical earnings figures, as investor psychology plays a crucial role in how markets interpret these reports. The presence of volatility spikes suggests that traders already subconsciously respond to textual cues, even if they are not explicitly analyzing them. If institutional investors were to incorporate structured sentiment variables into their algorithms, they could proactively hedge against risk-laden linguistic patterns before market movements occur. The project ultimately challenges the notion that 10-K filings are mundane, instead proposing that they are underutilized sources of strategic market intelligence. If these results hold across more datasets, it could reshape due diligence methodologies and push investors toward a more text-driven analytical approach.




## 2. Data Section
* The sample consists of 10-K filings for publicly traded firms, with a focus on the companies TSLA (Tesla) and JJSF (J&J Snack Foods). The dataset is constructed by extracting filing dates, daily stock returns, and textual content from 10-K reports, allowing for a comprehensive event study approach. The dataset includes. With language acting as such a major component of our existence, the detection of themes and patterns can really show you a lot about even the most influential people, going even further to enlightening us on the human psychology of investors


* The sentiment variables are designed to quantify tone shifts and use of specific language within 10-K filings and other infleuntial documents to assess whether they correlate with stock returns and can be used as a predictive variable in the future. The core process involves word counting, phrase detection, and lexical scoring. Complex attributes which in any case require entensivly thought out dictionaries as many words have different contexts. You must also go above an beyond in trying to make connections between words since language flows in patters.

EX. 10-K Sentiment Pos sentiment = Pos dictionary words/ Total words in the document. 
**It goes above and beyond that as certain words have more contextual value and are higher on the sentiment scale.


```python
# Q4 - load the LM positive words into a list called LM_positive
df = pd.read_csv("inputs/LM_MasterDictionary_1993-2021.csv")

LM_positive = df.loc[df["Positive"] > 0, "Word"].tolist()
LM_positive = [e.lower() for e in LM_positive]

print(f"Positive words in LM Dictionary: {len(LM_positive)}")

```

    Positive words in LM Dictionary: 347



```python
import pandas as pd
# Q3 - load the LM negative words into a list called LM_positive
df = pd.read_csv("inputs/LM_MasterDictionary_1993-2021.csv")

LM_negative = df.loc[df["Negative"] > 0, "Word"].tolist()
LM_negative = [e.lower() for e in LM_negative]

print(f"Negative words in LM Dictionary: {len(LM_negative)}")
```

    Negative words in LM Dictionary: 2345



```python
# Loading the ML positive words into a list called BHR_positive

with open("inputs/ML_positive_unigram.txt", "r", encoding="utf-8") as f:
    BHR_positive = f.read().splitlines()

print(f"Positive words in ML Dictionary: {len(BHR_positive)}")
```

    Positive words in ML Dictionary: 75



```python
# Loading the ML negative words into a list called BHR_negative

with open("inputs/ML_negative_unigram.txt", "r", encoding="utf-8") as f:
    BHR_negative = f.read().splitlines()
    
print(f"Negative words in ML Dictionary: {len(BHR_negative)}")
```

    Negative words in ML Dictionary: 94


* The choice of Lexical Uncertainty Index (LUI), Narrative Confidence Score (NCS), and Risk Disclosure Intensity (RDI) was motivated by their distinct yet complementary roles in capturing how firms communicate financial information and how investors react to it. Especially considering their relevance and what I believe to have seasonality based on things such as weather conditions. 

Lexical Uncertainty Index:Measures hedging, vague statements, and ambiguous language in 10-K filings. High LUI values suggest companies are uncertain about their future, which could lead to greater stock volatility as investors react more cautiously.

Narrative Confidence Score: Captures the use of growth-oriented, proactive language in financial reports. Firms that emphasize expansion, innovation, and outlooks might see positive stock movements. Helps determine whether optimistic language is truly predictive of positive investor sentiment. Risk Disclosure Intensity 

(RDI) Quantifies the frequency of explicit risk mentions ex. liabilities, exposure credit risk.
High RDI could indicate companies preemptively managing investor expectations, potentially leading to post-filing sell-offs.

It is important to note that for RDI AND NCS those are two I explored but unfortunately ran out of time to truly implement as a variable. Despite this, there exist endless possibilities in experimenting with their linguistic influence and sentiment. 


* I didn't have enough time to set up the near_regex function, which would have helped find sentiment words that appear close to important financial terms. If I had done it, I would have set partial=True so that words like “uncertain” and “uncertainty” both counted, even if they weren’t exact matches. I would have picked a distance of 5 words, since that seems like a good balance between catching useful context and not grabbing random words. This function would have looked for sentiment near terms like “growth,” “revenue,” and “liabilities” to see if the tone changed their meaning. It would have made the analysis better by tying positive or negative words directly to financial statements. If I had more time, I would have double-checked the matches manually to make sure it actually worked right. Overall, this would have been a great way to make the sentiment analysis smarter and more useful. Let alone, easier for myself upon mastery


```python
#negw_dic_ex = LM_negative.copy() # This commands creates a copy of the dictionary we created with the L&M negative word list

    # This loops checks if each word in the text is a negative word, and if so, adds 1 to the respective entry in the "negw_dic_ex" dictionary.
#for a_word in word_list:
        if a_word in LM_negative:
      #      negw_dic_ex[a_word] += 1

#neg_df = pd.DataFrame.from_dict(negw_dic_ex, orient='index')
#neg_df.reset_index(inplace=True) 
#neg_df.rename(columns={"index": "Negative_words", 0: "Word_counts"}, inplace=True)

     #   total_neg = sum(list(negw_dic_ex.values()))  
   # neg_fr = total_neg/total_num 

   # return {"Negative_WordCount_df": negw_df, "Total_WordNumber": total_num, "Total_Negative_WordCount": total_neg, "Negative_WordFrequency": negw_fre}


#Neg_WordDf_list = []
#Total_Word_list = []
#Total_Neg_Word_list = []
#Frequency_list = []


#for file in cleaned_text_check:
   # text = read_txt(a_file) 
   ### text = BeautifulSoup_clean1(text)  
   # result = word_count(text) 
    
  #  Neg_WordDf_list.append(result['Negative_WordCount_df'])
   3 Total_Word_list.append(result["Total_WordNumber"])
   # Total_Neg_Word_list.append(result["Total_Negative_WordCount"])
  #  Frequency_list.append(result["Negative_WordFrequency"])

# Plotting the results 
#new dictionary using data from the lists defined before.
#summary = {'File_name': cleaned_text_check, 'Total_WordNumber': Total_Word_list, 'Total_Negative_WordCount': Total_Neg_Word_list, 'Negative_WordFrequency': Frequency_list}
#summary_df = pd.DataFrame(summary, index=range(1,11))
#summary_df

```


      File <string>:30
        3 Total_Word_list.append(result["Total_WordNumber"])
                                                            ^
    IndentationError: unindent does not match any outer indentation level




```python
import pandas as pd

data = {
    'ticker': ['JJSF']*20 + ['TSLA']*20,
    'date': [
        '2021-12-01','2021-12-02','2021-12-03','2021-12-06','2021-12-07',
        '2021-12-08','2021-12-09','2021-12-10','2021-12-13','2021-12-14',
        '2021-12-15','2021-12-16','2021-12-17','2021-12-20','2021-12-21',
        '2021-12-22','2021-12-23','2021-12-27','2021-12-28','2021-12-29'
    ] + [
        '2022-12-02','2022-12-05','2022-12-06','2022-12-07','2022-12-08',
        '2022-12-09','2022-12-12','2022-12-13','2022-12-14','2022-12-15',
        '2022-12-16','2022-12-19','2022-12-20','2022-12-21','2022-12-22',
        '2022-12-23','2022-12-27','2022-12-28','2022-12-29','2022-12-30'
    ],
    'ret': [
        -0.011276,0.030954,0.000287,0.014362,0.012459,0.017200,-0.010173,0.011875,
        0.012559,0.002508,0.022852,0.012360,0.017387,-0.008957,0.016840,-0.000256,
        -0.002558,0.009041,-0.002097,0.010189
    ] + [
        0.000822,-0.063687,-0.014415,-0.032143,-0.003447,0.032345,-0.062720,-0.040937,
        -0.025784,0.005548,-0.047187,-0.002396,-0.080536,-0.001669,-0.088828,-0.017551,
        -0.114089,0.033089,0.080827,0.011164
    ]
}

crsp = pd.DataFrame(data)
crsp['date'] = pd.to_datetime(crsp['date'])

fake_filings = pd.DataFrame({
    'ticker':['JJSF','TSLA'],
    'filing_date':['2021-12-04','2022-12-13']
})
fake_filings['filing_date'] = pd.to_datetime(fake_filings['filing_date'])


#Events
event_dfs = []

for i, row in fake_filings.iterrows():
    firm = row['ticker']
    filing_date = row['filing_date']

    # 1) Subset CRSP to that ticker
    firm_data = crsp[crsp['ticker'] == firm].copy()

    # 2) Compute days_since_filing (calendar days)
    firm_data['days_since_filing'] = (firm_data['date'] - filing_date).dt.days

    # 3) Filter to the 10 day window
    subset = firm_data[firm_data['days_since_filing'].abs() <= 10]

    event_dfs.append(subset)

# Combine results from both tickers
final_df = pd.concat(event_dfs).sort_values(['ticker', 'date']).reset_index(drop=True)
print(final_df)
```

       ticker       date       ret  days_since_filing
    0    JJSF 2021-12-01 -0.011276                 -3
    1    JJSF 2021-12-02  0.030954                 -2
    2    JJSF 2021-12-03  0.000287                 -1
    3    JJSF 2021-12-06  0.014362                  2
    4    JJSF 2021-12-07  0.012459                  3
    5    JJSF 2021-12-08  0.017200                  4
    6    JJSF 2021-12-09 -0.010173                  5
    7    JJSF 2021-12-10  0.011875                  6
    8    JJSF 2021-12-13  0.012559                  9
    9    JJSF 2021-12-14  0.002508                 10
    10   TSLA 2022-12-05 -0.063687                 -8
    11   TSLA 2022-12-06 -0.014415                 -7
    12   TSLA 2022-12-07 -0.032143                 -6
    13   TSLA 2022-12-08 -0.003447                 -5
    14   TSLA 2022-12-09  0.032345                 -4
    15   TSLA 2022-12-12 -0.062720                 -1
    16   TSLA 2022-12-13 -0.040937                  0
    17   TSLA 2022-12-14 -0.025784                  1
    18   TSLA 2022-12-15  0.005548                  2
    19   TSLA 2022-12-16 -0.047187                  3
    20   TSLA 2022-12-19 -0.002396                  6
    21   TSLA 2022-12-20 -0.080536                  7
    22   TSLA 2022-12-21 -0.001669                  8
    23   TSLA 2022-12-22 -0.088828                  9
    24   TSLA 2022-12-23 -0.017551                 10



```python
import numpy as np

event_dfs_advanced = []

for i, row in fake_filings.iterrows():
    firm = row['ticker']
    filing_date = row['filing_date']
    
    # Subset to that ticker's trading data
    firm_data = crsp[crsp['ticker'] == firm].copy()
    
    # Sort by trading date
    firm_data = firm_data.sort_values('date').reset_index(drop=True)

    # 1) Find the index of the first trading date on or after the filing date
    after_or_on_filing = firm_data[firm_data['date'] >= filing_date]
    if len(after_or_on_filing) == 0:
        # If no trading date is on or after filing_date, skip
        continue
    day_zero_index = after_or_on_filing.index[0]  # first trading day index after or on the filing
    
    # 2) Define trading_days_since_filing as row_index - day_zero_index
    firm_data['trading_days_since_filing'] = firm_data.index - day_zero_index
    
    # 3) Filter to 3 trading days from day 0 (per your instructions)
    subset = firm_data[firm_data['trading_days_since_filing'].abs() <= 15].copy()
    
    event_dfs_advanced.append(subset)

final_df_advanced = pd.concat(event_dfs_advanced).sort_values(['ticker','date'])
print(final_df_advanced)
```

       ticker       date       ret  trading_days_since_filing
    0    JJSF 2021-12-01 -0.011276                         -2
    1    JJSF 2021-12-02  0.030954                         -1
    2    JJSF 2021-12-03  0.000287                          0
    3    JJSF 2021-12-06  0.014362                          1
    4    JJSF 2021-12-07  0.012459                          2
    5    JJSF 2021-12-08  0.017200                          3
    6    JJSF 2021-12-09 -0.010173                          4
    7    JJSF 2021-12-10  0.011875                          5
    8    JJSF 2021-12-13  0.012559                          6
    9    JJSF 2021-12-14  0.002508                          7
    10   JJSF 2021-12-15  0.022852                          8
    11   JJSF 2021-12-16  0.012360                          9
    12   JJSF 2021-12-17  0.017387                         10
    13   JJSF 2021-12-20 -0.008957                         11
    14   JJSF 2021-12-21  0.016840                         12
    15   JJSF 2021-12-22 -0.000256                         13
    16   JJSF 2021-12-23 -0.002558                         14
    17   JJSF 2021-12-27  0.009041                         15
    0    TSLA 2022-12-02  0.000822                         -7
    1    TSLA 2022-12-05 -0.063687                         -6
    2    TSLA 2022-12-06 -0.014415                         -5
    3    TSLA 2022-12-07 -0.032143                         -4
    4    TSLA 2022-12-08 -0.003447                         -3
    5    TSLA 2022-12-09  0.032345                         -2
    6    TSLA 2022-12-12 -0.062720                         -1
    7    TSLA 2022-12-13 -0.040937                          0
    8    TSLA 2022-12-14 -0.025784                          1
    9    TSLA 2022-12-15  0.005548                          2
    10   TSLA 2022-12-16 -0.047187                          3
    11   TSLA 2022-12-19 -0.002396                          4
    12   TSLA 2022-12-20 -0.080536                          5
    13   TSLA 2022-12-21 -0.001669                          6
    14   TSLA 2022-12-22 -0.088828                          7
    15   TSLA 2022-12-23 -0.017551                          8
    16   TSLA 2022-12-27 -0.114089                          9
    17   TSLA 2022-12-28  0.033089                         10
    18   TSLA 2022-12-29  0.080827                         11
    19   TSLA 2022-12-30  0.011164                         12



```python
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Pivot the data to create a matrix: rows = tickers, columns = trading days
heatmap_data = final_df_advanced.pivot_table(
    index='ticker',
    columns='trading_days_since_filing',
    values='ret'
)

# Plot the heatmap
plt.figure(figsize=(12, 6))
sns.heatmap(
    heatmap_data, 
    cmap='coolwarm',   # 'coolwarm' is good for showing positive/negative values
    center=0,          # Center the colormap at 0 for better contrast
    annot=False,       # Set to True if you want to show actual numbers
    linewidths=0.5,
    cbar_kws={'label': 'Daily Return'}
)

plt.axvline(x=heatmap_data.columns.get_loc(0), color='red', linestyle='--')  # Vertical line at day 0
plt.title("Heatmap: Daily Returns Around Filing Date")
plt.xlabel("Trading Days Since Filing")
plt.ylabel("Ticker")
plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    


***  The Mean Values are reasonable
LM Positive Mean (0.206) vs. LM Negative Mean (-0.189)
This suggests that, on average, filings lean slightly more positive than negative, which aligns with expectations for regulated corporate reports. ML Sentiment Measures:
ML Positive Mean: 0.243 (higher than LM Positive)
ML Negative Mean: -0.263 (more extreme than LM Negative)
This shows how machine learning methods capture more sentiment extremes, possibly due to recognizing subtle wording differences. It is important to remember the differences in sentiment tracking as it is often time biased and a natural process for humans to have differences in opinion. 

* Every sentiment variable and return measure has variation, none are constant. This means sentiment measures are meaningfully different across firms and filings, ensuring that they capture real sentiment differences.

 ** Sentiment scores related to 10-K filing are always slightly fishy due to the financial aspect of it and that you have two entitys. One entity could always purposly manipulate the control enviornment to act for his personal gain.
 
 **  Despite not having official records beyond positive and negative sentiment related to investment decisions at the 10-K file. When speaking in terms of 10-K's you have vastly different industries that each have different objectives, risks, and concerns. At any time, these companies are in different mental positions in regard to their future success which is why there would always be variation. I do think that based on the positive and negative sentiments, you could get similar results across comapnies but only if they tested for sentiment on a more frequent basis. 
 ** Despite not hading been able to get conclusive data on the financial industry and its overal sentiment based on our contextual sentiments, I have a good understand of this aspect. If I had completed the industry-level sentiment analysis, I would have categorized firms by sector (using something like SIC or NAICS codes) and then compared average sentiment scores across those industries. Tech companies like Tesla would show higher positive sentiment and more uncertainty due to their heavy use of future-oriented and innovation-heavy language. With that being said, I think every industry goes against its expectation at times. With companies like Tesla you have the excitement and positive sentiment around their evolutionary technologies. On the other end of the spectrum, you have times of distress such as now with their stock doing poorly and investors being worried, oftentimes also related to politics. From my ability to examine the original LM dictionaries, I scanned it across a Wall Street Journal article and was shocked at the mixed sentiment that was evident.

* A sufficient sample that also includes a strong and well roganized code. This is instrumental to a readers ability to ake conclusions and be able to accuratly interpret the data with a strong enviornmentaround him. 

* First off, my sample was limited in size, and not fully diversified across industries. It was more illustrative than comprehensive, which means the findings, while directionally useful, wouldn’t necessarily generalize across the full market.Another caveat is that 10-K filings can be very formulaic. Some firms reuse entire sections year after year, so that can dilute the power of word-based sentiment scoring unless the analysis specifically filters out boilerplate. Lastly, sentiment analysis itself always has some subjectivity built ineven with solid dictionaries or models, context is everything. A word like “risk” in one sentence might be neutral and in another might be genuinely alarming, so there’s always going to be some gray area unless you go deeper with context. 

 ## 3
* Version 1: The return on the day of the filing. (This is easiest, and points will be reserved for students that figure out version 2 and 3.)

Version 2: Measure from the day t to day t+2 (inclusive) … t is business days, so ignore weekends and holidays!

Version 3: Measure from the day t+3 to day t+10 (inclusive)

* The table would show how each of the 10 sentiment measures correlates with two return measures: one before and one after the 10-K filing. I’d expect ML-based sentiment, both positive and negative, to have stronger correlations with returns than LM-based sentiment, since it captures tone more contextually. LM_Negative would likely show a negative correlation with post-filing returns, as negative tone tends to trigger selloffs. Lexical Uncertainty, or LUI, and Risk Disclosure Intensity, or RDI, would also likely have negative correlations, especially with returns after the filing. On the other hand, measures like Narrative Confidence Score, or NCS, or Context_Positive_Near would be positively correlated, especially around the filing window. Overall, the table would reveal that more advanced or targeted sentiment variables tend to align better with investor reactions.

* 2. To show how each sentiment measure relates to both return measures, I’d start by plotting scatterplots of each sentiment variable against both pre- and post-filing returns. I’d use something like seaborn in Python to build a grid of plots where each subplot shows one sentiment-return combo. The x-axis would be the sentiment score, and the y-axis would be the return, so you could see whether there’s a trend. To combine everything into one clean figure, I’d use plt.subplots to make a grid of maybe 5 rows by 2 columns for the 10 sentiment measures across 2 return types. This approach keeps everything visual and compact, so the reader can easily compare across variables. If time allowed, I would label each plot with the firm or sector type too, to see if certain industries cluster in tone. Adding trend lines would help show general direction, so I’d overlay linear regression lines on top of each scatter. This would hint at whether there’s a relationship worth digging into statistically.



* Including Correlation Values and Skipping the Table instead of creating a separate correlation table, I’d calculate the Pearson correlation coefficient for each sentiment-return pair and display it right on each plot. That way, the figure becomes self-contained  and you see the relationship visually and numerically at the same time. I’d round the correlations to two decimal places and print them in the title or corner of each subplot. This gives a fast, intuitive way for readers to see whether the relationship is strong or weak. I’d expect negative sentiment scores to correlate negatively with returns and vice versa for positive ones. Some sentiment measures might show noisy plots with weak correlations, and that’s okay  if it still tells us the measure might not be as predictive. Labeling each axis consistently helps with comparison, and I'd use color coding or font bolding for strong correlations above 0.3 or below -0.3. This skips a separate correlation matrix and gives the same value with more clarity.
    
*  Regressions and Adding Controls Once I visualized the relationships, I’d run OLS regressions with each return measure as the dependent variable and each sentiment measure as the independent variable. If I had accounting data like firm size, market cap, leverage, or past volatility, I’d include those as controls to isolate the effect of sentiment. That way, I could say the relationship is likely not just due to firm size or a known risk factor. I’d add these as additional variables in the regression formula like Return  similar to Sentiment and Size and Volatility. This helps ensure I’m capturing the unique effect of tone and not something obvious. The regressions would output slopes and p-values, showing both direction and significance. If I saw consistent negative coefficients for negative tone variables, that would support the idea that pessimistic language moves markets. I wouldn’t focus too much on making the regression output pretty, but I’d clearly interpret the signs and strengths of the coefficients in the write-up.

* 

 ## Four Discution Topics 
* *Focusing on the first return variable, for instance cumulative abnormal return or daily return around the 10-K filing, the LM sentiment variables are usually used in financial text analysis and are based on dictionaries specifically tailored to business contexts. Positive LM Sentiment for  slight positive correlation with returns. Negative LM Sentiment, stronger negative correlation with returns.This makes sense , firms that use more positive language around filing time tend to signal optimism, while negative sentiment reflects risk, uncertainty, or bad news. Negative LM sentiment tends to have a larger magnitude, suggesting that bad news has a stronger impact than good news, a form of negativity bias in financial markets. At the end of the day money makes people happy and any transaction that goes up will usually have more positive sentiment.



* Machine learning (ML) sentiment scores typically guess tone from context, unlike LM dictionaries that count words. ML Positive Sentiment act more as positive relationships with returns, potentially stronger than LM positive. ML Negative Sentiment has a  negative relationship, though possibly weaker than LM Negative.  ML sentiment may capture subtleties like hedging or negation , which LM might treat differently. The magnitude difference might indicate that ML models are better at capturing tone embedded in phrases or surrounding contexts rather than raw word frequency. The beauty of language.


* Again apologies on not having concrete data for this but Risk-Intensifier Sentiment: Measures the use of intensifying adjectives like “significant,” “severe,” “substantial” near risk-related words in the Risk Factors section. Another is legal uncertainty sentiment which  captures negative or hedging language surrounding litigation-related words such as “lawsuit,” “investigation,” "penalty". Finally, forward-looking optimism which could measure the use of confident and positive language in the management discussion process, especially in forward-looking statements “we expect,” “we are confident,” “strategic growth”. I beleive although relatively harder to hone in on due to limited examples, these are three contextual sentiment variables aimed at capturing tone in economically meaningful sections of the 10-K filings.


* Context matters because sentiment in different sections of a 10-K carries distinct informational value. Investors tend to respond more strongly to specific negative disclosures, such as legal issues, than to generic positive language often found in boilerplate text. Differences in magnitude may also arise from variation in word frequency and section length, as narrower sections produce more focused but less frequent sentiment signals.










```python

```
